[x,y,z]=meshgrid(-20:4:20,-20:4:20,-20:4:20);
a=atan((x.^2+y.^2)./z);
b=atan(y./x);
r=(x.^2+y.^2+z.^2).^(1/2);
U=-0.00001;
%��Ծ����
u=heaviside(r-1).*(U.*cos(a).*(1-1.5*1./r+0.5*1./(r.^3))).*sin(a).*cos(b)+(U.*sin(a).*(1-0.75*1./r-0.25*1./(r.^3))).*cos(a).*cos(b);
v=heaviside(r-1).*(U.*cos(a).*(1-3/2*1./r+1/2*1./(r.^3))).*sin(a).*sin(b)+(U.*sin(a).*(1-3/4*1./r-1/4*1./(r.^3))).*cos(a).*sin(b);
w=heaviside(r-1).*(U.*cos(a).*(1-3/2*1./r+1/2*1./(r.^3))).*cos(a)+(U.*sin(a).*(1-3/4*1./r-1/4*1./(r.^3))).*sin(a);
res=heaviside(r-1);
list=-20:5:20;
%quiver3(x,y,z,u,v,w)
[sx, sy, sz] = meshgrid(-20:4:20,-20:4:20,-20:4:20);
streamline(x,y,z,u,v,w,sx,sy,sz)
view(3);
xlabel x;
ylabel y;
zlabel z;
grid on